peque.work = function () {
    'use strict';

    var init = function ()
    {

    };


    return {
        init: init
    };
}();
