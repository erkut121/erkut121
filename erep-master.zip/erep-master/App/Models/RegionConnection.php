<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RegionConnection extends Model {
    protected $fillable = ["region_a", "region_b"];
}